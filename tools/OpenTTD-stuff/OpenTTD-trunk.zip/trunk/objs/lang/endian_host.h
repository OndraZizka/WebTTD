#ifndef ENDIAN_H
#define ENDIAN_H
#define TTD_ENDIAN TTD_LITTLE_ENDIAN
#endif
