/* $Id: music.h 17248 2009-08-21 20:21:05Z rubidium $ */

/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <http://www.gnu.org/licenses/>.
 */

/** @file music.h Base for the music handling. */

#ifndef MUSIC_H
#define MUSIC_H

#define NUM_SONGS_PLAYLIST 33
#define NUM_SONGS_AVAILABLE 22

struct SongSpecs {
	char filename[MAX_PATH];
	char song_name[64];
};

extern const SongSpecs _origin_songs_specs[];

#endif /* MUSIC_H */
