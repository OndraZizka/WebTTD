/* $Id: signs_type.h 17248 2009-08-21 20:21:05Z rubidium $ */

/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <http://www.gnu.org/licenses/>.
 */

/** @file signs_type.h Types related to signs */

#ifndef SIGNS_TYPE_H
#define SIGNS_TYPE_H

typedef uint16 SignID;
struct Sign;

enum {
	INVALID_SIGN = 0xFFFF,

	MAX_LENGTH_SIGN_NAME_BYTES  =  31, ///< The maximum length of a sign name in bytes including '\0'
	MAX_LENGTH_SIGN_NAME_PIXELS = 255, ///< The maximum length of a sign name in pixels
};

#endif /* SIGNS_TYPE_H */
