#include <stdio.h>

int main(int argc, char *argv[])
{
	FILE *f;
	unsigned char *content;
	long size;
	unsigned int offset;

	f = fopen("openttd.exe", "rb");
	if (f == NULL) {
		fprintf(stdout, "failed to open openttd.exe for read\n");
		return -1;
	}

	fseek(f, 0, SEEK_END);
	size = ftell(f);
	rewind(f);
	content = calloc(size, sizeof(char));

	fread(content, 1, size, f);
	fclose(f);

	// retrieve the PE header pointer
	offset = ((content[0x3f] << 8 | content[0x3e]) << 8 | content[0x3d]) << 8 | content[0x3c];
	// add the offset to subsystem from PE header start
	offset += 92;

	switch (content[offset]) {
		case 2:
			printf("GUI mode detected. Converting to console.\n");
			content[offset] = 3;
			break;
		case 3:
			printf("Console mode detected. Converting to GUI.\n");
			content[offset] = 2;
			break;
		default:
			printf("Unknown mode.\n");
			return 0;
	}

	f = fopen("openttd.exe", "wb");
	if (f == NULL) {
		fprintf(stdout, "failed to open openttd.exe for write\n");
		return -1;
	}

	fwrite(content, 1, size, f);
	fclose(f);
	free(content);

	return 0;
}
