Guy Images by: Cartoon Smart
tilefill by: OscarMedina

tile fill usage: index.php?color=*hexcolor* // ie: index.php?color=CCCCCC