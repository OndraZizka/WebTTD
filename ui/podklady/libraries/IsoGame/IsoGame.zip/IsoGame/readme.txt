Guy Images by: Cartoon Smart
tilefill by: OscarMedina
PHP fixed by Ondra Zizka. See also the WebTTD project.